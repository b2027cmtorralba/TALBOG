
package tile;

import game.GamePanel;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.imageio.ImageIO;

public class TileManager {
  GamePanel gp;
  Tile [] tile;
  
  int mapTileNum[][];
  
  public TileManager(GamePanel gp) {
      this.gp = gp;
      tile = new Tile[10]; //10 tile patterns
      mapTileNum = new int[gp.maxScreenCol][gp.maxScreenRow];
      getTileImage();
      loadMap();
  }
  public void getTileImage(){
      try{
          tile[0] = new Tile();
          tile[0].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile.png"));
          tile[0].collision = true;
          tile[1] = new Tile();
          tile[1].image = ImageIO.read(getClass().getResourceAsStream("/tiles/wood.png"));
         
      }
      catch(IOException e){
          e.printStackTrace();
      }
  }
  public void loadMap(){
      try{
          InputStream is = getClass().getResourceAsStream("/maps/maptest.txt");
          BufferedReader br = new BufferedReader(new InputStreamReader(is));
          
          int col =0;
          int row =0;
          while(col<gp.maxScreenCol && row<gp.maxScreenRow){
              String line = br.readLine(); //reads a single line of txt map file
              while(col<gp.maxScreenCol){
                  String numbers[] = line.split("");// gets the single number for each line
                  int num = Integer.parseInt(numbers[col]);//number from string to int
                  
                  mapTileNum[col][row] = num;
                  col++;
                 
              }
              if(col == gp.maxScreenCol){
                  col=0;
                  row++;
                  
              }
          }
          br.close();
      }catch(Exception e){
          e.getMessage();
      }
  }
  public void printTile(Graphics2D g2){
      int col = 0;
      int row = 0;
      int x = 0;
      int y = 0;
      
      while(col<gp.maxScreenCol && row<gp.maxScreenRow){
          int tileNum = mapTileNum[col][row];// acts as index
          g2.drawImage(tile[tileNum].image, x, y, gp.tileSize, gp.tileSize, null);
          col++;
          x+=gp.tileSize;
          
          if(col == gp.maxScreenCol){
              col = 0;
              x = 0;
              row++;
              y+=gp.tileSize;
          }
      }
      /* test that each tile prints
       g2.drawImage(tile[0].image, y, x, gp.tileSize, gp.tileSize, null);
       g2.drawImage(tile[1].image, 50, x, gp.tileSize, gp.tileSize, null);
       g2.drawImage(tile[0].image, 100, x, gp.tileSize, gp.tileSize, null);
      */
  }
}
