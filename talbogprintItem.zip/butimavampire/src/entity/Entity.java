package entity;
import java.awt.image.BufferedImage;

public class Entity {

    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }
    int x;
    int y;
    public int speed;
    int hp;
    
    public BufferedImage up1, up2, up3,down1, down2, down3, left1, left2, left3, right1, right2, right3;
    public String direction, name;
    
    public int spriteCounter = 0;
    public int spriteNum = 1;

    /**
     * @return the hp
     */
    public  int getHp() {
        return hp;
    }
    public void setHp(int hp) {
        this.hp = hp;
    }
    
  
}
