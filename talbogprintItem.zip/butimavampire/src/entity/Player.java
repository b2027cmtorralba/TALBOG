package entity;
//C:\Users\Marga Torralba\Documents\NetBeansProjects\game\src\player
import game.GamePanel;
import game.KeyHandler;
//import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public final class Player extends Entity{
    GamePanel gp;
    KeyHandler keyH;
    
    public Player(GamePanel gp, KeyHandler keyH){
        this.gp = gp;
        this.keyH = keyH;
        
        setDefaultValues();
        getPlayerImage();
    }
    public Player (int hp){super.hp = hp;}
    public void setDefaultValues(){
        x = 100;
        y = 100;
        speed = 4; 
        direction = "down";
    }
    public void getPlayerImage(){
        try {/*replace up1 and up2 later */ 
            up1 = ImageIO.read(getClass().getResourceAsStream("/player/vb_up_1.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("/player/up_1.5.png"));
            up3 = ImageIO.read(getClass().getResourceAsStream("/player/vb_up_2.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("/player/vb_down_1.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("/player/down_1.5.png"));
            down3 = ImageIO.read(getClass().getResourceAsStream("/player/vb_down_2.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("/player/vb_left_1.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/player/vb_left_1.5.png"));
            left3 = ImageIO.read(getClass().getResourceAsStream("/player/vb_left_2.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/player/vb_right_1.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/player/vb_right_1.5.png"));
            right3 = ImageIO.read(getClass().getResourceAsStream("/player/vb_right_2.png"));
            
            
            
            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void update(){
        if(keyH.up == true){
            direction ="up";
            y -= speed;
        }
        if(keyH.down == true){
            direction = "down";
            y += speed;
        }
        if(keyH.left == true){
            direction = "left";
            x -= speed;
        }
        if(keyH.right == true){
            direction ="right";
            x += speed;
        }
        /*else{
            direction="idle";
            
        }*/
        spriteCounter++;
        if(spriteCounter > 10) {
            switch (spriteNum) {
                case 1 -> spriteNum = 2;
                case 2 -> spriteNum =3;
                case 3 -> spriteNum = 1;
                default -> {
                }
            }
            
            spriteCounter = 0;
        }
    }
    public void draw(Graphics2D g2){
        BufferedImage image = null;
        
        switch(direction) {
            case "up" -> {
                if(spriteNum == 1){
                    image = up1;
                }
                if(spriteNum == 2){
                    image = up2;
                }
                if(spriteNum == 3){
                    image = up3;
                }
            }      
            case "down" -> {
                if(spriteNum == 1){
                   image = down1;
                }
                if(spriteNum == 2) {
                    image = down2;
                }
                if(spriteNum == 3){
                    image = down3;
                }
                
            }
            case "left" ->{
                if(spriteNum == 1){
                    image = left1;
                }
                if(spriteNum == 2){
                    image = left2;
                }
                if(spriteNum == 3){
                    image = left3;
                }
            }
            case "right" -> {
                if(spriteNum == 1){
                    image = right1;
                }
                if(spriteNum == 2){
                    image = right2;
                }
                if(spriteNum == 3){
                    image = right3;
                }
            }
            case "idle" -> {
                if(spriteNum == 1){
                    image = down2;
                }
                if(spriteNum == 2){
                    image = down1;
                }
                if(spriteNum == 2){
                    image = down2;
                }
                
                /* add down/idel png later*/
            }
        }
        System.out.println("G2 in gp:" + g2); 
        g2.drawImage(image, getX(), getY(), 60, 130, null);
    }
}

