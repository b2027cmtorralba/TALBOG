/*width of enemySide and playerSide 384!!!
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

import items.Item;
import entity.Enemy;
import entity.Entity;
import entity.Player;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

public class BattleLayout extends JFrame implements ActionListener{
    private JPanel enemySide, enemyHpBar, playerSide, playerHpBar, menu, bag, options;
    private JLabel Enemy, Player, Icon, enemyHp, playerHp, enemyName, playerName, title, ehp, php;
    private ImageIcon enemyIMG, playerIMG, iconIMG;
    private JButton run, talk, attack, manakot, item;
    private int x;//for bag
    
    private Entity enemy, player;
    public BattleLayout(Enemy enemy, Player player){//add enemy and player parameters later to find which enemy and character sprite to print
        super("Battle");
        this.enemy = enemy; this.player = player;
        this.setLayout(new BorderLayout(0,0));
        Border blackline = BorderFactory.createLineBorder(Color.black);
        Border whiteline = BorderFactory.createLineBorder(Color.white);
        
        Icon = new JLabel();
        iconIMG = new ImageIcon(BattleLayout.class.getResource("/player/icon.png"));
        Icon.setIcon(iconIMG);
        Enemy = new JLabel("enemy");
        Player = new JLabel("player");
        
        // for test w/out entity parameters
        JLabel ename = new JLabel ("PRES.");
        JLabel pname = new JLabel ("V. BANGKAY");
        ehp = new JLabel();
        php = new JLabel();
        
        if(enemy.getHp()>75){
            ehp.setText("<3<3<3<3<3");
        }
        else if(enemy.getHp()>50&&enemy.getHp()<=75){
            ehp.setText("<3<3<3<");
        }
        else if(enemy.getHp()>25&&enemy.getHp()<=50){
            ehp.setText("<3<3<");
        }
        else if(enemy.getHp()>12&&enemy.getHp()<=25){
            ehp.setText("<3");
        }
        else if(enemy.getHp()<=12){
            ehp.setText("<");
        }
        if(player.getHp()>75){
            php.setText("<3<3<3<3<3");
        }
        else if(player.getHp()>50&&player.getHp()<=75){
            php.setText("<3<3<3<");
        }
        else if(player.getHp()>25&&player.getHp()<=50){
            php.setText("<3<3<");
        }
        else if(player.getHp()>12&&player.getHp()<=25){
            php.setText("<3");
        }
        else if(player.getHp()<=12){
            php.setText("<");
        }
        
        //JLabel bag = new JLabel("bag");
        JLabel Options = new JLabel("options");
        JLabel icon = new JLabel("icon");
        
        enemySide = new JPanel();
        enemySide.setLayout(new BorderLayout(0,0));
        playerSide = new JPanel();
        playerSide.setLayout(new BorderLayout(0,0));
        enemyHpBar = new JPanel();
        enemyHpBar.setLayout(new BorderLayout(0,0));
        playerHpBar = new JPanel();
        playerHpBar.setLayout(new BorderLayout(0,0));
        menu = new JPanel();
        menu.setLayout(new BorderLayout(0,0));
        options = new JPanel();
        options.setLayout(new GridLayout(5,1));
        
        
              
        //enemyHpBar
        enemySide.add(ename, BorderLayout.NORTH);
        ename.setPreferredSize(new Dimension(384,30));
        ename.setBorder(blackline);
        enemySide.add(ehp, BorderLayout.CENTER);
        ehp.setPreferredSize(new Dimension(384,48));
        ehp.setBorder(blackline);
        //Enemy
        enemySide.add(Enemy, BorderLayout.SOUTH);
        Enemy.setPreferredSize(new Dimension(384, 480));
        Enemy.setBorder(blackline);
     
        //Player
        playerSide.add(Player, BorderLayout.NORTH);
        Player.setPreferredSize(new Dimension(384,480));
        Player.setBorder(blackline);
        //playerHpBar
        playerSide.add(php, BorderLayout.SOUTH);
        php.setPreferredSize(new Dimension(384,30));
        php.setBorder(blackline);
        playerSide.add(pname, BorderLayout.CENTER);
        pname.setPreferredSize(new Dimension(384,48));
        pname.setBorder(blackline);
        
        // bag
        JLabel bagTitle = new JLabel("bag: ");
        bagTitle.setForeground(Color.white);
        x = Item.geInventoryLength();
        bag = new JPanel();
        bag.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx=0;c.gridy=0;
        bag.add(bagTitle, c);

        c.gridy=1;
        for(int i = 0; i<x; i++){
            c.gridx=(i+1);
            ArrayList<Item> inventory = Item.getInventory();
            String name =  inventory.get(i).getName();
            item = new JButton(name);
            bag.add(item, c);
            item.addActionListener(this);
        }
        x = Item.geInventoryLength();//reset for actionEvent
                       
        //options
        title = new JLabel("select your next move", SwingConstants.CENTER);
        options.add(title);
        title.setForeground(Color.white);
        title.setBackground(Color.black);
        run = new JButton("run");
        talk = new JButton("talk");
        attack = new JButton("punch");
        manakot = new JButton("manakot");
        options.add(run);
        options.add(talk);
        options.add(attack);
        options.add(manakot);
        
        //menu
        menu.add(bag, BorderLayout.NORTH);
        bag.setPreferredSize(new Dimension(200, 96));
        bag.setBorder(whiteline);
        menu.add(options, BorderLayout.CENTER);
        options.setPreferredSize(new Dimension(200,192));
        options.setBorder(whiteline);
        menu.add(Icon, BorderLayout.SOUTH);
        Icon.setPreferredSize(new Dimension(200,288));
        Icon.setBorder(whiteline);
        bag.setForeground(Color.white);
        bag.setBackground(Color.black);
        bag.setOpaque(true);
        options.setForeground(Color.white);
        options.setBackground(Color.black);
        options.setOpaque(true);
    
        
        this.add(enemySide, BorderLayout.WEST);
        this.add(playerSide, BorderLayout.CENTER);
        this.add(menu, BorderLayout.EAST);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(968,576);
        this.setVisible(true);
        
      
    }
    public void updateHp(){
        if(enemy.getHp()>75){
            ehp.setText("<3<3<3<3<3");
        }
        else if(enemy.getHp()>50&&enemy.getHp()<=75){
            ehp.setText("<3<3<3<");
        }
        else if(enemy.getHp()>25&&enemy.getHp()<=50){
            ehp.setText("<3<3<");
        }
        else if(enemy.getHp()>12&&enemy.getHp()<=25){
            ehp.setText("<3");
        }
        else if(enemy.getHp()<=12){
            ehp.setText("<");
        }
        
        if(player.getHp()>75){
            php.setText("<3<3<3<3<3");
        }
        else if(player.getHp()>50&&player.getHp()<=75){
            php.setText("<3<3<3<");
        }
        else if(player.getHp()>25&&player.getHp()<=50){
            php.setText("<3<3<");
        }
        else if(player.getHp()>12&&player.getHp()<=25){
            php.setText("<3");
        }
        else if(player.getHp()<=12){
            php.setText("<");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       //test 
       JButton clicked = (JButton) e.getSource();
       String itemString = clicked.getText();
       
       Item theItem = Item.searchInventory(itemString);
       Item.use(theItem, enemy, player);
       System.out.print("you used " + itemString);
       updateHp();
       
       
       clicked.setVisible(false);
      
    }
}

