/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import javax.swing.*;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;

public class MainMenuLayout  extends JFrame {
    ImageIcon avatar;
   JPanel buttonPanel, imgPanel;
   JButton start, load,quit;
   JLabel tittle, label;
   public MainMenuLayout(/*ImageIcon img*/){
       super("Menu");
        avatar = new ImageIcon(getClass().getResource("Nosferatu.jpg"));
        buttonPanel = new JPanel();
        imgPanel = new JPanel();
        
         start = new JButton("Start");
         load  = new JButton("Load");
         quit = new JButton("Quit");
         tittle = new JLabel("But I'm A Vampire");
         label = new JLabel();

        label.setIcon(avatar);
        imgPanel.setLayout(new FlowLayout()); 
        imgPanel.add(label);
        imgPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        
        tittle.setFont(new Font("Serif", Font.PLAIN, 20));
        
        buttonPanel.setLayout(new GridBagLayout()); 
        GridBagConstraints gbc = new GridBagConstraints();  
        
        gbc.gridx = 0;  gbc.gridy = 0;  
        gbc.fill = GridBagConstraints.HORIZONTAL; 
        buttonPanel.add(tittle,gbc);

        
        gbc.gridx = 0;  gbc.gridy = 1;  
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        buttonPanel.add(start,gbc);
        
        gbc.gridx = 0;  gbc.gridy = 2;  
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        buttonPanel.add(load, gbc);
        
        gbc.gridx = 0;  gbc.gridy = 3; 
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        buttonPanel.add(quit,gbc);
        

        buttonPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        buttonPanel.setPreferredSize(new Dimension(350, 190));
        
        this.setLayout(new FlowLayout(FlowLayout.CENTER));
        this.setSize(968,576);
        this.setResizable(false);
        this.setBackground(Color.pink);
        this.add(imgPanel);
        this.add(buttonPanel);
        this.setVisible(true);
        
    }

}
