/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

import java.awt.BorderLayout;
import static java.awt.BorderLayout.CENTER;
import static java.awt.BorderLayout.NORTH;
import static java.awt.BorderLayout.WEST;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

/**
 *
 * @author Marga Torralba
 */
public class About extends JFrame implements ActionListener{
    private JButton back;
    private JLabel img, info;
    private JPanel container;
    public About(){
        super("about");
        super.setLayout(new BorderLayout());
         Border blackline = BorderFactory.createLineBorder(Color.black);
         container = new JPanel();
         
        info = new JLabel("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.");
        info.setSize(698,576);
        info.setBorder(blackline);
        back = new JButton("return");
        img = new JLabel("img");
        container.add(img);
        container.setSize(300,400);
        container.setBorder(blackline);
        back.addActionListener(this);
        JPanel footer = new JPanel();
        footer.setLayout(new FlowLayout());
        footer.add(back);
        this.add(footer, BorderLayout.SOUTH);
        this.add(container, NORTH);
        this.add(info, CENTER);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(968,576);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        MainMenuLayout menu = new MainMenuLayout();
        this.dispose();
        
    }
}
