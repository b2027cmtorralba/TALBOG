/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

import items.Item;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class OverworldLayout extends JFrame {
    GamePanel gp;
    JPanel tab, options, menu, character;
    JButton save, bag, hp;
    
    public OverworldLayout(GamePanel gp){
        super("overworld");
        Border whiteline = BorderFactory.createLineBorder(Color.white);
        GamePanel gamePanel = gp;
        JPanel tab = new JPanel();
        JPanel options = new JPanel();
        JPanel menu = new JPanel();
        JPanel dialogPanel = new JPanel();
        JPanel character = new JPanel();
        JPanel inv = new JPanel();
        JPanel menuDialog = new JPanel();
        ImageIcon portraitImg;
        
        JButton save = new JButton("save");
        JLabel dialog = new JLabel("dialog");
        JLabel hp = new JLabel("hp");
        JLabel portrait = new JLabel();
        JLabel empty = new JLabel("");
        
        portrait = new JLabel();
        portraitImg = new ImageIcon(BattleLayout.class.getResource("/player/icon.png"));
        portrait.setIcon(portraitImg);
        
        menu.setLayout(new BorderLayout(0,0));
        menu.setPreferredSize(new Dimension(200,576));
        
        JLabel invTitle = new JLabel("bag: ");
        invTitle.setForeground(Color.white);
        int x = Item.geInventoryLength();
        inv.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx=0;c.gridy=0;
        inv.add(invTitle, c);
        
        c.gridy=1;
        for(int i = 0; i<x; i++){
            c.gridx=(i+1);
            ArrayList<Item> inventory = Item.getInventory();
            String name =  inventory.get(i).getName();
            JButton item = new JButton(name);
            inv.add(item, c);
        }
        
        menu.add(inv, BorderLayout.NORTH);
        inv.setForeground(Color.white);
        inv.setBackground(Color.black);
        inv.setBorder(whiteline);
        
        dialog.setPreferredSize(new Dimension(200,192));
        dialog.setForeground(Color.white);
        hp.setPreferredSize(new Dimension(200,96));
        hp.setForeground(Color.white);
        hp.setBorder(whiteline);
        menuDialog.setLayout(new BorderLayout(0,0));
        menuDialog.add(dialog, BorderLayout.NORTH);
        menuDialog.add(hp, BorderLayout.CENTER);
        menuDialog.setBorder(whiteline);
        
        menu.add(menuDialog,  BorderLayout.CENTER);
        menu.add(portrait, BorderLayout.SOUTH);
        portrait.setBorder(whiteline);
        this.setLayout(new BorderLayout(0,0));
        this.setSize(968,576);
        this.add(menu, BorderLayout.EAST);
        
        menuDialog.setBackground(Color.black);
        this.add(gamePanel, BorderLayout.CENTER);//dapat huli iadd yung gamePanel
                
        this.pack();
        
        this.setLocationRelativeTo(null);
        
        this.setVisible(true);
        
    }
    
}
